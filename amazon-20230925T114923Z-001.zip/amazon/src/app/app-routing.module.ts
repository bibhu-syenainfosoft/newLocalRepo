import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AmazonElectronicsComponent } from './components/amazon-electronics/amazon-electronics.component';
import { AmazonHomeComponent } from './components/amazon-home/amazon-home.component';
import { AmazonJeweleryComponent } from './components/amazon-jewelery/amazon-jewelery.component';
import { AmazonMensComponent } from './components/amazon-mens/amazon-mens.component';
import { AmazonWomenComponent } from './components/amazon-women/amazon-women.component';
import { NotfoundComponent } from './components/notfound/notfound.component';

const routes: Routes = [
  {path: "home", component: AmazonHomeComponent},
  {path: "jewelery", component: AmazonJeweleryComponent},
  {path: "electronics", component: AmazonElectronicsComponent},
  {path: "mens", component: AmazonMensComponent},
  {path: "women", component: AmazonWomenComponent},
  {path: "",  redirectTo:"home", pathMatch: "full" },
  {path: "**", component: NotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
