import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-home',
  templateUrl: './amazon-home.component.html',
  styleUrls: ['./amazon-home.component.css']
})
export class AmazonHomeComponent {

}
