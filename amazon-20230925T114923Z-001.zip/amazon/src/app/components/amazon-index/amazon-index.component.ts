import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-index',
  templateUrl: './amazon-index.component.html',
  styleUrls: ['./amazon-index.component.css']
})
export class AmazonIndexComponent {

}
