import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-electronics',
  templateUrl: './amazon-electronics.component.html',
  styleUrls: ['./amazon-electronics.component.css']
})
export class AmazonElectronicsComponent {

}
