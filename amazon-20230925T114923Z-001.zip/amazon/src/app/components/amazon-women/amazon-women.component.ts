import { Component } from '@angular/core';

@Component({
  selector: 'app-amazon-women',
  templateUrl: './amazon-women.component.html',
  styleUrls: ['./amazon-women.component.css']
})
export class AmazonWomenComponent {

}
