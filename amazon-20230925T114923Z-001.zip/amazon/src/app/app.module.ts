import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AmazonIndexComponent } from './components/amazon-index/amazon-index.component';
import { AmazonHomeComponent } from './components/amazon-home/amazon-home.component';
import { AmazonJeweleryComponent } from './components/amazon-jewelery/amazon-jewelery.component';
import { AmazonElectronicsComponent } from './components/amazon-electronics/amazon-electronics.component';
import { AmazonMensComponent } from './components/amazon-mens/amazon-mens.component';
import { AmazonWomenComponent } from './components/amazon-women/amazon-women.component';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { FakestoreService } from './services/fakestore.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AmazonIndexComponent,
    AmazonHomeComponent,
    AmazonJeweleryComponent,
    AmazonElectronicsComponent,
    AmazonMensComponent,
    AmazonWomenComponent,
    NotfoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [FakestoreService],
  bootstrap: [AmazonIndexComponent]
})
export class AppModule { }
